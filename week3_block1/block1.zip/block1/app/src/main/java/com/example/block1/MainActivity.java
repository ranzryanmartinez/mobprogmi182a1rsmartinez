package com.example.block1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity<Button> extends AppCompatActivity {

    Button buttonBlue, buttonPink;
    private View v;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonBlue = (Button) findViewById(R.id.button_blueinvisible);
        buttonPink = (Button) findViewById(R.id.button_pinkpanther);
    }

    public void ToDo(View v) {
        if (v.equals(buttonBlue))
            // invisibility
            v.setVisibility(View.INVISIBLE);
        if (v.equals(buttonPink))
            // pop-up
            Toast.makeText(getApplicationContext(),
                    "to do to do to do...",
                    Toast.LENGTH_SHORT).show();


    }
}
